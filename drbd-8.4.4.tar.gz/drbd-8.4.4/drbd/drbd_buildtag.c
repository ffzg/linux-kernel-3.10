/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 74402fecf24da8e5438171ee8c19e28627e1c98a"
		" build by lars@soda, 2013-12-23 21:21:27";
}
