/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
#include <linux/drbd_config.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 1d360bde0e095d495786eaeb2a1ac76888e4db96"
		" build by phil@fat-tyre, 2014-06-02 15:07:37";
}
